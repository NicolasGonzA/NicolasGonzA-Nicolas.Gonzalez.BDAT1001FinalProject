﻿using System.Collections.Generic;
using System.Security.Claims;
using System.Threading.Tasks;
using MailKit;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.UI.Services;
using Microsoft.AspNetCore.Mvc;
using NETCore.MailKit.Core;

namespace IdentityExample
{
    public class HomeController : Controller

    {

        private readonly UserManager<IdentityUser> _userManager;
        private readonly SignInManager<IdentityUser> _SignInManager;
        private readonly IEmailSender _emailService;

        public HomeController(
            UserManager<IdentityUser>userManager,
            SignInManager<IdentityUser>signInManager,
            IEmailSender emailService)
        {
            _userManager = userManager;
            _SignInManager = signInManager;
            _emailService = emailService;
        }

        public IActionResult Index()
        {
            return View();
        }


        [Authorize]
        public IActionResult Secret()
        {
            return View();
        }

        public IActionResult Login()
        { 
            return View();

        }
        [HttpPost]

        public async Task<IActionResult> Login(string username, string password)
        {
            // login functionality
            var user = await _userManager.FindByNameAsync(username);

            if (user !=null)
            {
                // sign in

              var singInResult = await  _SignInManager.PasswordSignInAsync(user, password, false, false);
                if (singInResult.Succeeded)
                {
                    return RedirectToAction("Index");
                }
            }

          return  RedirectToAction("Index");
        }

        public IActionResult Register()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult>Register(string username, string password)
        {
            // register functionality

            var user = new IdentityUser
            {
                UserName = username,
                Email = "",

            };
            
            var result = await _userManager.CreateAsync(user, password);

            if (result.Succeeded)
            {
                //generation of the email token

                var code = await _userManager.GenerateEmailConfirmationTokenAsync(user);

                var link = Url.Action(nameof(VerifyEmail), "Home", new { userId = user.Id, code }, Request.Scheme, Request.Host.ToString());

                await _emailService.SendAsync("test@test.com", "email verify", $"<a href=\"{link}\">Verify Email</a>", true);
               
                return RedirectToAction("EmailVerification");
            }
            return RedirectToAction("Index");
        }

        public async Task<IActionResult>VerifyEmail(string userId, string code)
        {
            var user = await _userManager.FindByIdAsync(userId);

            if (user == null) return BadRequest();

            var result = await _userManager.ConfirmEmailAsync(user, code);

            if (result.Succeeded)

            {
                return View();

            }

            return BadRequest();

        }
        public IActionResult EmailVerification() => View();

        public async Task<IActionResult> LogOut()
        {
            await _SignInManager.SignOutAsync();
            return RedirectToAction("Index");
        }

    }

}
